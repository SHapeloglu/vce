-- =============================================================================
-- VCE (Validity Control Engine) — MailSender Pro Şeması
-- =============================================================================
-- Bu dosya çalıştırıldığında veri kalitesi altyapısının tüm tabloları oluşur.
-- Sadece bir kez çalıştırılır. İdempotent: IF NOT EXISTS ile tekrar çalıştırılabilir.
--
-- TABLOLAR:
--   1. vce_dq_rules             — Veri kalitesi kuralları (tek gerçek kaynağı)
--   2. vce_dq_executions        — Her kural çalışmasının sonucu
--   3. vce_table_validations    — Kaynak-hedef karşılaştırma tanımları
--   4. vce_table_val_executions — Karşılaştırma sonuçları
--   5. vce_rule_audit_log       — Kural değişiklik geçmişi (kim ne zaman değiştirdi)
--   6. vce_remediation_log      — Otomatik temizlik işlemleri kayıtları
--   7. vce_anomaly_baselines    — Anomali tespiti için istatistiksel taban değerleri
-- =============================================================================

-- =============================================================================
-- 1. VCE_DQ_RULES — Veri Kalitesi Kural Tanımları
-- =============================================================================
-- Her satır bir veri kalitesi kuralını temsil eder.
-- Kurallar domain/subdomain ile gruplanır (ör: domain='send_log', subdomain='failed_ratio').
-- sql_statement: Sonucu > 0 ise kural ihlali anlamına gelir (COUNT(*) döndürmeli).
-- pre_sql_statement: Asıl kontrolden önce hazırlık amaçlı çalıştırılır (ör: geçici tablo).
-- check_type: Kuralın kategorisi — anomali tespiti için farklı mantık uygulanır.
-- execute_time: Bu kuralın hangi saatteki DAG çalışmasında aktif olduğu (ör: '06:00').
-- active_flag: 0 yapılırsa kural devre dışı kalır, kod değiştirilmesine gerek yok.
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_dq_rules (
    id                  INT AUTO_INCREMENT PRIMARY KEY,

    -- Gruplama
    rule_domain         VARCHAR(100) NOT NULL   COMMENT 'Ana kategori (ör: send_log, suppression, queue)',
    rule_subdomain      VARCHAR(100) NOT NULL   COMMENT 'Alt kategori (ör: failed_ratio, null_check)',

    -- Hedef tablo bilgisi (bilgi amaçlı, sorguda kullanılmaz)
    dataset_name        VARCHAR(100)            COMMENT 'Hangi mantıksal veritabanı/dataset',
    table_name          VARCHAR(200)            COMMENT 'Hangi tablo denetleniyor',

    -- Kural mantığı
    check_type          ENUM(
                            'threshold',     -- Sabit eşik: sonuç > 0 ise fail
                            'anomaly',       -- Dinamik: geçmiş ortalamaya göre anomali
                            'freshness',     -- Taze veri: tablonun son güncelleme zamanı
                            'volume',        -- Hacim: beklenen satır sayısı aralığı
                            'schema',        -- Şema: kolon varlığı/tipi
                            'duplicate',     -- Tekrar: unique ihlali
                            'custom'         -- Özel: herhangi bir SQL
                        ) NOT NULL DEFAULT 'threshold'  COMMENT 'Kontrol tipi — anomaly için istatistik motoru devreye girer',

    sql_statement       TEXT NOT NULL           COMMENT 'Çalıştırılacak SQL. Sonucu > 0 ise kural ihlali. COUNT(*) döndürmeli.',
    pre_sql_statement   TEXT                    COMMENT 'Asıl SQL öncesi çalışan hazırlık sorgusu (geçici tablo vb.)',

    -- Aksiyon
    action              ENUM('fail', 'warn')
                            NOT NULL DEFAULT 'fail'   COMMENT 'fail: DAG durdurur + Teams. warn: Teams + email, DAG devam eder.',
    description         TEXT NOT NULL           COMMENT 'İnsan okunabilir açıklama. Neden var? Ne kontrol ediyor?',

    -- Anomali eşiği (check_type=anomaly için)
    anomaly_threshold   DECIMAL(10,4)           COMMENT 'Ortalamadan kaç standart sapma uzaklaşırsa anomali sayılır (varsayılan: 3)',

    -- Zamanlama
    execute_time        VARCHAR(10)             COMMENT 'Hangi saatteki çalışmada aktif. Ör: 06:00. NULL ise her çalışmada.',
    active_flag         TINYINT(1) NOT NULL DEFAULT 1  COMMENT '1: aktif, 0: devre dışı (kod değiştirilmeden kapatılır)',

    -- Metadata
    author              VARCHAR(100)            COMMENT 'Kuralı oluşturan kişi',
    test_flag           TINYINT(1) NOT NULL DEFAULT 0  COMMENT '1: test modunda — sonuçlar loglanır ama aksiyon alınmaz',
    non_active_description TEXT                 COMMENT 'Neden devre dışı bırakıldığının açıklaması',

    -- Zaman damgaları
    insert_timestamp    DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_timestamp    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_domain    (rule_domain, rule_subdomain),
    INDEX idx_active    (active_flag),
    INDEX idx_time      (execute_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Veri kalitesi kural tanımları. Yeni kural eklemek için INSERT yeterli, kod değişmez.';


-- =============================================================================
-- 2. VCE_DQ_EXECUTIONS — Kural Çalışma Sonuçları
-- =============================================================================
-- Her kural çalıştığında bir satır eklenir.
-- result_value: SQL'in döndürdüğü sayısal sonuç.
-- result_status: 'Passed' (0) veya 'Failed' (>0).
-- Bu tablo trend analizi ve dashboard için temel kaynaktır.
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_dq_executions (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,

    -- Hangi kural?
    rule_id             INT                     COMMENT 'vce_dq_rules.id — JOIN için',
    rule_domain         VARCHAR(100) NOT NULL,
    rule_subdomain      VARCHAR(100) NOT NULL,
    dataset_name        VARCHAR(100),
    table_name          VARCHAR(200),
    check_type          VARCHAR(50),

    -- Airflow bağlamı
    dag_id              VARCHAR(200) NOT NULL   COMMENT 'Hangi DAG çalıştı',
    dag_task_name       VARCHAR(200)            COMMENT 'Hangi task',
    dag_run             VARCHAR(500)            COMMENT 'DAG run ID (tarih + schedule)',

    -- SQL ve sonuç
    sql_statement       TEXT                    COMMENT 'Çalışan SQL (değişebilir, anlık snapshot)',
    action              VARCHAR(10)             COMMENT 'fail veya warn',
    result_value        DECIMAL(20,4)           COMMENT 'SQL sonucu (COUNT, SUM vb.)',
    result_status       ENUM('Passed','Failed','Skipped','Error')
                            NOT NULL DEFAULT 'Passed'  COMMENT 'Kontrol sonucu',
    error_detail        TEXT                    COMMENT 'SQL hatası veya anomali detayı',

    -- Anomali bilgisi (check_type=anomaly için dolar)
    baseline_mean       DECIMAL(20,4)           COMMENT 'Geçmiş 30 günlük ortalama',
    baseline_std        DECIMAL(20,4)           COMMENT 'Geçmiş 30 günlük standart sapma',
    z_score             DECIMAL(10,4)           COMMENT 'Hesaplanan Z-skoru (|z| > eşik ise anomali)',

    run_date            DATETIME DEFAULT CURRENT_TIMESTAMP  COMMENT 'Bu satırın eklendiği zaman',

    INDEX idx_domain    (rule_domain, rule_subdomain),
    INDEX idx_run_date  (run_date),
    INDEX idx_status    (result_status),
    INDEX idx_rule_id   (rule_id),
    INDEX idx_dag       (dag_id, run_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Her kural çalışmasının sonucu. Trend analizi ve dashboard için temel kaynak.';


-- =============================================================================
-- 3. VCE_TABLE_VALIDATIONS — Kaynak-Hedef Karşılaştırma Tanımları
-- =============================================================================
-- İki sorgunun sonucunu karşılaştırır. Senin VCE'deki TableValidationOperator gibi.
-- MailSender'da kullanım: send_log satır sayısı ile send_queue_log satır sayısını karş.
-- Veya: suppression_list ile send_log'da suppressed adrese gönderim karşılaştırması.
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_table_validations (
    id                  INT AUTO_INCREMENT PRIMARY KEY,

    validation_domain   VARCHAR(100) NOT NULL   COMMENT 'Ana kategori (ör: send_consistency)',
    validation_subdomain VARCHAR(100) NOT NULL  COMMENT 'Alt kategori (ör: queue_vs_log)',

    -- Kaynak
    source_conn_id      VARCHAR(100) NOT NULL   COMMENT 'Airflow connection ID (mailsender_mysql)',
    source_dataset      VARCHAR(100)            COMMENT 'Kaynak mantıksal dataset',
    source_table        VARCHAR(200)            COMMENT 'Kaynak tablo adı',
    source_sql          TEXT NOT NULL           COMMENT 'Kaynak sorgusu — sonuç hedefle karşılaştırılır',
    pre_source_sql      TEXT                    COMMENT 'Kaynak sorgusundan önce çalışacak hazırlık SQL',

    -- Hedef
    target_conn_id      VARCHAR(100) NOT NULL   COMMENT 'Airflow connection ID (aynı veya farklı DB)',
    target_dataset      VARCHAR(100)            COMMENT 'Hedef mantıksal dataset',
    target_table        VARCHAR(200)            COMMENT 'Hedef tablo adı',
    target_sql          TEXT NOT NULL           COMMENT 'Hedef sorgusu — kaynak ile karşılaştırılır',
    pre_target_sql      TEXT                    COMMENT 'Hedef sorgusundan önce çalışacak hazırlık SQL',

    -- Karşılaştırma tipi
    comparison_type     ENUM('exact','count','sum','tolerance')
                            NOT NULL DEFAULT 'exact'  COMMENT 'exact: birebir eşleşme. tolerance: yüzde fark izni.',
    tolerance_pct       DECIMAL(5,2)            COMMENT 'comparison_type=tolerance için izin verilen yüzde fark (ör: 1.5)',

    -- Aksiyon ve durum
    action              ENUM('fail','warn') NOT NULL DEFAULT 'fail',
    description         TEXT NOT NULL,
    active_flag         TINYINT(1) NOT NULL DEFAULT 1,
    author              VARCHAR(100),
    execute_time        VARCHAR(10),
    test_flag           TINYINT(1) NOT NULL DEFAULT 0,

    insert_timestamp    DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_timestamp    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_domain    (validation_domain, validation_subdomain),
    INDEX idx_active    (active_flag)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Kaynak-hedef tablo karşılaştırma tanımları.';


-- =============================================================================
-- 4. VCE_TABLE_VAL_EXECUTIONS — Karşılaştırma Sonuçları
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_table_val_executions (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,

    validation_id       INT                     COMMENT 'vce_table_validations.id',
    validation_domain   VARCHAR(100) NOT NULL,
    validation_subdomain VARCHAR(100) NOT NULL,

    dag_id              VARCHAR(200) NOT NULL,
    dag_task_name       VARCHAR(200),
    dag_run             VARCHAR(500),
    task_retry_count    INT DEFAULT 0,

    source_conn_id      VARCHAR(100),
    source_dataset      VARCHAR(100),
    source_table        VARCHAR(200),
    source_sql          TEXT,
    source_result       MEDIUMTEXT              COMMENT 'Kaynak sorgu sonucu (max 1000 satır)',

    target_conn_id      VARCHAR(100),
    target_dataset      VARCHAR(100),
    target_table        VARCHAR(200),
    target_sql          TEXT,
    target_result       MEDIUMTEXT              COMMENT 'Hedef sorgu sonucu',

    result_status       ENUM('Passed','Failed','Error') NOT NULL,
    diff_detail         TEXT                    COMMENT 'Eşleşmeyen satır veya değer detayı',

    run_date            DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_domain    (validation_domain, validation_subdomain),
    INDEX idx_run_date  (run_date),
    INDEX idx_status    (result_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Kaynak-hedef karşılaştırma çalışma sonuçları.';


-- =============================================================================
-- 5. VCE_RULE_AUDIT_LOG — Kural Değişiklik Geçmişi
-- =============================================================================
-- vce_dq_rules tablosundaki her INSERT/UPDATE/DELETE işlemi buraya kaydedilir.
-- Kim, ne zaman, neyi değiştirdi? Tam iz kalır.
-- Airflow DAG bu tabloyu doğrudan doldurmaz; MySQL trigger veya uygulama katmanı doldurur.
-- Alternatif: DAG içinde kural yüklenirken checksum karşılaştırması yapılır.
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_rule_audit_log (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    rule_id             INT NOT NULL            COMMENT 'Değişen kural ID',
    rule_domain         VARCHAR(100),
    rule_subdomain      VARCHAR(100),

    change_type         ENUM('INSERT','UPDATE','DELETE','ACTIVATE','DEACTIVATE')
                            NOT NULL            COMMENT 'Ne tür değişiklik yapıldı',

    -- Önceki ve sonraki değerler (JSON veya metin)
    old_sql             TEXT                    COMMENT 'Değişiklikten önceki SQL',
    new_sql             TEXT                    COMMENT 'Değişiklikten sonraki SQL',
    old_action          VARCHAR(10),
    new_action          VARCHAR(10),
    old_active_flag     TINYINT(1),
    new_active_flag     TINYINT(1),

    changed_by          VARCHAR(100)            COMMENT 'Değişikliği yapan kullanıcı (Airflow user veya DB user)',
    change_reason       TEXT                    COMMENT 'Neden değiştirildi? (isteğe bağlı not)',
    changed_at          DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_rule      (rule_id),
    INDEX idx_changed   (changed_at),
    INDEX idx_type      (change_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Kural değişiklik geçmişi. Kim ne zaman ne değiştirdi? Tam audit trail.';


-- =============================================================================
-- 6. VCE_REMEDIATION_LOG — Otomatik Temizlik Kayıtları
-- =============================================================================
-- RemediationOperator her çalıştığında ne sildiğini/düzelttini buraya yazar.
-- Böylece "Bu gece ne silindi?" sorusu yanıtlanabilir.
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_remediation_log (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,

    dag_id              VARCHAR(200) NOT NULL,
    dag_run             VARCHAR(500),
    task_name           VARCHAR(200),

    operation_type      ENUM(
                            'delete_expired_tokens',
                            'delete_old_rate_logs',
                            'delete_old_ses_notif',
                            'delete_expired_unsub',
                            'flag_stuck_queue',
                            'report_suppression_violation',
                            'custom'
                        ) NOT NULL              COMMENT 'Yapılan temizlik işleminin tipi',

    target_table        VARCHAR(200) NOT NULL   COMMENT 'İşlem yapılan tablo',
    sql_executed        TEXT                    COMMENT 'Çalıştırılan SQL',
    rows_affected       INT DEFAULT 0           COMMENT 'Etkilenen satır sayısı',

    result_status       ENUM('Success','Failed','Warning') NOT NULL DEFAULT 'Success',
    result_detail       TEXT                    COMMENT 'Başarı mesajı veya hata detayı',

    executed_at         DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_type      (operation_type),
    INDEX idx_table     (target_table),
    INDEX idx_date      (executed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Otomatik temizlik işlemleri kayıtları. Ne silindiği, kaç satır etkilendiği.';


-- =============================================================================
-- 7. VCE_ANOMALY_BASELINES — Anomali Tespiti Taban Değerleri
-- =============================================================================
-- Anomali tespiti için her kural bazında istatistiksel taban tutulur.
-- Airflow DAG her çalışmada bu tabloyu günceller (30 günlük kayan pencere).
-- Sonraki çalışmada mevcut değer bu tabloyla karşılaştırılır.
-- Z-skoru = (mevcut_değer - mean) / std — |z| > threshold ise anomali.
-- =============================================================================
CREATE TABLE IF NOT EXISTS vce_anomaly_baselines (
    id                  INT AUTO_INCREMENT PRIMARY KEY,

    rule_id             INT NOT NULL            COMMENT 'vce_dq_rules.id',
    rule_domain         VARCHAR(100) NOT NULL,
    rule_subdomain      VARCHAR(100) NOT NULL,

    -- 30 günlük kayan pencere istatistikleri
    window_days         INT NOT NULL DEFAULT 30 COMMENT 'Kaç günlük geçmiş kullanıldı',
    sample_count        INT NOT NULL DEFAULT 0  COMMENT 'Hesaplamada kullanılan örnek sayısı',
    mean_value          DECIMAL(20,4)           COMMENT 'Ortalama değer',
    std_value           DECIMAL(20,4)           COMMENT 'Standart sapma',
    min_value           DECIMAL(20,4)           COMMENT 'Minimum',
    max_value           DECIMAL(20,4)           COMMENT 'Maksimum',
    p25_value           DECIMAL(20,4)           COMMENT '25. persentil',
    p75_value           DECIMAL(20,4)           COMMENT '75. persentil',

    last_updated        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uk_rule  (rule_id),
    INDEX idx_domain    (rule_domain, rule_subdomain)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COMMENT='Anomali tespiti için istatistiksel taban değerleri. DAG her çalışmada günceller.';
