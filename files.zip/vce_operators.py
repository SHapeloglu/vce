"""
vce_operators.py
================
MailSender Pro — VCE (Validity Control Engine) Custom Airflow Operatörleri
=========================================================================

Bu dosyadaki sınıflar Apache Airflow'un BaseOperator'ından türetilmiştir.
Senin orijinal VCE projenin mimarisi esas alınarak MySQL için yeniden yazılmıştır.

SINIFLAR:
  1. VCEBaseOperator        — Ortak yardımcı metodlar (bağlantı, kayıt, bildirim)
  2. DataQualityOperator    — SQL tabanlı veri kalitesi kurallarını çalıştırır
  3. TableValidationOperator— Kaynak-hedef tablo karşılaştırması yapar
  4. RemediationOperator    — Otomatik temizlik işlemleri yapar

DÜZELTILEN SORUNLAR (orijinal VCE'deki bug'lar):
  - fail_checks = [] class variable → instance variable yapıldı (paralel run güvenli)
  - SQL injection → parametre binding kullanıldı
  - Hardcoded webhook URL → Airflow Variable'a taşındı
  - vce_monitoring'deki eksik raise → düzeltildi
  - Tüm DB bağlantıları finally bloğunda kapatılıyor

BAĞIMLILIKLAR:
  pip install apache-airflow pymysql

AIRFLOW CONNECTION:
  Conn Id  : mailsender_mysql
  Conn Type: MySQL (veya Generic)
  Host     : host.docker.internal
  Schema   : mailsender
  Login    : airflow_dq
  Port     : 3306
"""

from __future__ import annotations

import json
import logging
import statistics
from datetime import datetime
from typing import Any

import pymysql
import pymysql.cursors
import requests

from airflow.exceptions import AirflowException
from airflow.hooks.base import BaseHook
from airflow.models import BaseOperator, Variable
from airflow.utils.decorators import apply_defaults


# ── Sabitler ─────────────────────────────────────────────────────────────────
MYSQL_CONN_ID = "mailsender_mysql"

# Anomali tespiti: varsayılan Z-skoru eşiği
# |z| > 3 ise bu değer ortalamadan 3 standart sapma uzakta — %99.7 güven aralığı dışında
DEFAULT_ANOMALY_THRESHOLD = 3.0

# Teams/Slack bildirim URL'si Airflow Variable'dan okunur
# Airflow UI → Admin → Variables → VCE_TEAMS_WEBHOOK_URL
TEAMS_WEBHOOK_VAR = "VCE_TEAMS_WEBHOOK_URL"
SLACK_WEBHOOK_VAR = "VCE_SLACK_WEBHOOK_URL"


# ── VCEBaseOperator ──────────────────────────────────────────────────────────

class VCEBaseOperator(BaseOperator):
    """
    Tüm VCE operatörlerinin türetildiği temel sınıf.

    Sağladığı ortak işlevler:
      - MySQL bağlantısı (get_connection)
      - Sorgu çalıştırma (run_query, scalar)
      - Execution kaydı yazma (log_execution)
      - Teams ve Slack bildirimleri (notify_teams, notify_slack)
      - Kural audit logu (log_rule_change)

    NOT: fail_checks ve warn_checks, __init__ içinde instance variable olarak
    tanımlanmıştır. Orijinal VCE'deki class variable bug'ı (tüm instance'ların
    aynı listeyi paylaşması) bu şekilde düzeltilmiştir.
    """

    @apply_defaults
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # DÜZELTME: Class variable değil, instance variable — paralel task'larda güvenli
        self.fail_checks: list[str] = []
        self.warn_checks: list[str] = []
        self._conn = None

    # ── Bağlantı ─────────────────────────────────────────────────────────────

    def get_connection(self) -> pymysql.Connection:
        """
        Airflow Connection kaydından PyMySQL bağlantısı oluşturur.

        Connection Airflow'da 'mailsender_mysql' ID'siyle kayıtlı olmalıdır.
        Her operatör çalışması için yeni bağlantı açılır, finally bloğunda kapatılır.
        autocommit=False: her DML işlemini manuel commit etmek gerekir.
        """
        conn_info = BaseHook.get_connection(MYSQL_CONN_ID)
        return pymysql.connect(
            host=conn_info.host,
            port=int(conn_info.port or 3306),
            user=conn_info.login,
            password=conn_info.password,
            database=conn_info.schema,
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=False,
            connect_timeout=15,
        )

    def run_query(self, sql: str, params: tuple = ()) -> list[dict]:
        """
        Parametre binding ile SQL çalıştırır, sonuç listesi döner.

        GÜVENLIK: sql içindeki %s placeholder'larına params değerleri
        PyMySQL tarafından escape edilerek atanır — SQL injection riski yok.

        Args:
            sql   : Çalıştırılacak SQL. Parametreler için %s kullanın.
            params: SQL parametreleri. Tek parametre için (value,) şeklinde tuple.

        Returns:
            Her satırın dict olduğu liste. Sonuç yoksa boş liste.
        """
        conn = self.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchall() or []
        finally:
            conn.close()

    def scalar(self, sql: str, params: tuple = (), default: Any = 0) -> Any:
        """
        Tek değer dönen SQL için kısayol.

        Args:
            sql    : Tek sütun, tek satır döndüren SQL.
            params : SQL parametreleri.
            default: Sonuç boşsa döndürülecek varsayılan değer.

        Returns:
            İlk satırın ilk sütununun değeri, yoksa default.
        """
        rows = self.run_query(sql, params)
        if rows:
            return list(rows[0].values())[0]
        return default

    def execute_dml(self, sql: str, params: tuple = ()) -> int:
        """
        INSERT/UPDATE/DELETE çalıştırır, etkilenen satır sayısını döner.

        Başarıyla commit eder. Hata durumunda rollback yapar.
        """
        conn = self.get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                affected = cur.rowcount
            conn.commit()
            return affected
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ── Execution Kaydı ─────────────────────────────────────────────────────

    def log_execution(
        self,
        dag: dict,
        rule_id: int | None,
        rule_domain: str,
        rule_subdomain: str,
        dataset_name: str | None,
        table_name: str | None,
        check_type: str,
        sql_statement: str,
        action: str,
        result_value: float,
        result_status: str,
        error_detail: str | None = None,
        baseline_mean: float | None = None,
        baseline_std: float | None = None,
        z_score: float | None = None,
    ) -> None:
        """
        Kural çalışma sonucunu vce_dq_executions tablosuna kaydeder.

        Orijinal VCE'deki f-string INSERT yerine parametre binding kullanılmıştır.
        Bu hem SQL injection'ı önler hem de uzun SQL veya özel karakter sorununu çözer.
        """
        sql = """
            INSERT INTO vce_dq_executions (
                rule_id, rule_domain, rule_subdomain,
                dataset_name, table_name, check_type,
                dag_id, dag_task_name, dag_run,
                sql_statement, action,
                result_value, result_status, error_detail,
                baseline_mean, baseline_std, z_score,
                run_date
            ) VALUES (
                %s, %s, %s,
                %s, %s, %s,
                %s, %s, %s,
                %s, %s,
                %s, %s, %s,
                %s, %s, %s,
                NOW()
            )
        """
        params = (
            rule_id, rule_domain, rule_subdomain,
            dataset_name, table_name, check_type,
            dag["dag_id"], dag.get("task_name"), dag.get("dag_run"),
            sql_statement[:3000] if sql_statement else None,  # Max 3000 karakter
            action,
            result_value, result_status, error_detail,
            baseline_mean, baseline_std, z_score,
        )
        try:
            self.execute_dml(sql, params)
        except Exception as e:
            # Execution kaydı başarısız olursa sadece logla, exception fırlatma
            self.log.warning(f"Execution kaydı yazılamadı: {e}")

    # ── Bildirimler ──────────────────────────────────────────────────────────

    def notify_teams(self, title: str, checks: list[str]) -> None:
        """
        Microsoft Teams kanalına webhook ile bildirim gönderir.

        Webhook URL'si Airflow Variable'dan okunur (hardcoded değil!).
        Variable yoksa sessizce geçer — bildirim yokken DAG durmamalı.
        """
        try:
            webhook_url = Variable.get(TEAMS_WEBHOOK_VAR, default_var=None)
            if not webhook_url:
                self.log.warning("Teams webhook URL bulunamadı. "
                                 f"Airflow Variable '{TEAMS_WEBHOOK_VAR}' tanımlı mı?")
                return

            message = {
                "summary": f"VCE: {title}",
                "themeColor": "FF0000" if "fail" in title.lower() else "FFA500",
                "sections": [{
                    "activityTitle": f"🚨 VCE Veri Kalitesi: {title}",
                    "activitySubtitle": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
                    "facts": [
                        {"name": f"Kontrol {i+1}:", "value": check}
                        for i, check in enumerate(checks[:20])  # Max 20 madde
                    ],
                    "markdown": True,
                }],
            }

            response = requests.post(
                webhook_url,
                json=message,
                headers={"Content-Type": "application/json"},
                timeout=10,
            )

            if response.status_code == 200:
                self.log.info("Teams bildirimi gönderildi.")
            else:
                self.log.warning(f"Teams bildirimi başarısız: {response.status_code}")

        except Exception as e:
            self.log.warning(f"Teams bildirimi gönderilemedi: {e}")

    def notify_slack(self, title: str, checks: list[str]) -> None:
        """
        Slack kanalına webhook ile bildirim gönderir.

        Webhook URL'si Airflow Variable'dan okunur (VCE_SLACK_WEBHOOK_URL).
        """
        try:
            webhook_url = Variable.get(SLACK_WEBHOOK_VAR, default_var=None)
            if not webhook_url:
                return  # Slack ayarlı değilse sessizce geç

            emoji = "🔴" if any("fail" in c.lower() for c in checks) else "🟡"
            text = "\n".join(f"• {c}" for c in checks[:20])
            payload = {
                "text": f"{emoji} *VCE: {title}*\n{text}"
            }

            response = requests.post(webhook_url, json=payload, timeout=10)
            if response.status_code == 200:
                self.log.info("Slack bildirimi gönderildi.")

        except Exception as e:
            self.log.warning(f"Slack bildirimi gönderilemedi: {e}")

    def send_notifications(self, title: str, checks: list[str]) -> None:
        """Teams ve Slack bildirimini birlikte gönderir."""
        if checks:
            self.notify_teams(title, checks)
            self.notify_slack(title, checks)


# ── DataQualityOperator ──────────────────────────────────────────────────────

class DataQualityOperator(VCEBaseOperator):
    """
    SQL tabanlı veri kalitesi kurallarını çalıştıran operatör.

    vce_dq_rules tablosundan rule_domain + rule_subdomain kombinasyonuna
    göre aktif kuralları yükler ve her birini çalıştırır.

    Kural tipleri:
      - threshold: sql_statement sonucu > 0 ise ihlal
      - anomaly  : geçmiş 30 günlük istatistikle Z-skoru hesaplar
      - freshness, volume, duplicate, schema, custom: threshold gibi çalışır

    Aksiyon:
      - fail: fail_checks listesine eklenir → tüm kontroller bittikten sonra
              AirflowException fırlatılır (DAG görevi başarısız olur)
      - warn: warn_checks listesine eklenir → bildirim gidilir ama DAG devam eder

    test_flag=1 olan kurallar çalışır ve loglanır ama aksiyon alınmaz.

    template_fields ile DAG template değişkenleri desteklenir.
    Ör: rule_domain="{{ dag_run.conf.get('domain', 'send_log') }}"
    """

    template_fields = ("rule_domain", "rule_subdomain", "execute_time")

    @apply_defaults
    def __init__(
        self,
        rule_domain: str,
        rule_subdomain: str | None = None,
        execute_time: str | None = None,
        *args,
        **kwargs,
    ):
        """
        Args:
            rule_domain   : Hangi domain'deki kurallar çalıştırılacak (ör: 'send_log')
            rule_subdomain: İsteğe bağlı — belirli bir subdomain filtrelemek için
            execute_time  : İsteğe bağlı — hangi saatteki kurallar (ör: '06:00')
        """
        super().__init__(*args, **kwargs)
        self.rule_domain = rule_domain
        self.rule_subdomain = rule_subdomain
        self.execute_time = execute_time

    def execute(self, context: dict) -> None:
        dag = {
            "dag_id"  : context["dag"].dag_id,
            "dag_run" : context["dag_run"].run_id,
            "task_name": context["task"].task_id,
        }

        # Kuralları yükle
        rules = self._load_rules()
        self.log.info(f"📋 {len(rules)} kural yüklendi: {self.rule_domain}/{self.rule_subdomain or '*'}")

        # Her kuralı çalıştır
        for rule in rules:
            self._execute_rule(rule, dag)

        # Bildirim ve aksiyon
        if self.warn_checks:
            self.log.warning(f"⚠️ {len(self.warn_checks)} uyarı var.")
            self.send_notifications(f"Data Quality WARN — {self.rule_domain}", self.warn_checks)

        if self.fail_checks:
            self.send_notifications(f"Data Quality FAIL — {self.rule_domain}", self.fail_checks)
            raise AirflowException(
                f"❌ {len(self.fail_checks)} veri kalitesi kuralı başarısız:\n"
                + "\n".join(self.fail_checks)
            )

        self.log.info(f"✅ Tüm kontroller tamamlandı. Domain: {self.rule_domain}")

    def _load_rules(self) -> list[dict]:
        """vce_dq_rules tablosundan filtreli kural listesi döner."""
        conditions = ["active_flag = 1", "rule_domain = %s"]
        params: list = [self.rule_domain]

        if self.rule_subdomain:
            conditions.append("rule_subdomain = %s")
            params.append(self.rule_subdomain)

        if self.execute_time:
            conditions.append("(execute_time = %s OR execute_time IS NULL)")
            params.append(self.execute_time)

        sql = f"""
            SELECT id, rule_domain, rule_subdomain, dataset_name, table_name,
                   check_type, sql_statement, pre_sql_statement,
                   action, description, anomaly_threshold, test_flag
            FROM vce_dq_rules
            WHERE {' AND '.join(conditions)}
            ORDER BY rule_domain, rule_subdomain
        """
        return self.run_query(sql, tuple(params))

    def _execute_rule(self, rule: dict, dag: dict) -> None:
        """
        Tek bir kuralı çalıştırır: pre_sql → sql → aksiyon → kayıt.

        Kural tipine göre farklı mantık uygular:
          - threshold/freshness/volume/duplicate/schema/custom: sonuç > 0 ise ihlal
          - anomaly: Z-skoru hesaplanır, eşik aşılırsa ihlal
        """
        rule_id     = rule["id"]
        domain      = rule["rule_domain"]
        subdomain   = rule["rule_subdomain"]
        check_type  = rule["check_type"]
        sql         = rule["sql_statement"]
        pre_sql     = rule["pre_sql_statement"]
        action      = rule["action"]
        description = rule["description"]
        test_flag   = rule["test_flag"]
        anomaly_thr = rule.get("anomaly_threshold") or DEFAULT_ANOMALY_THRESHOLD

        baseline_mean = baseline_std = z_score_val = None

        try:
            # 1. Hazırlık sorgusu varsa çalıştır
            if pre_sql and pre_sql.strip():
                self.log.info(f"🔧 pre_sql çalıştırılıyor: [{domain}/{subdomain}]")
                self.run_query(pre_sql)

            # 2. Asıl sorguyu çalıştır
            self.log.info(f"🔍 Kontrol: [{domain}/{subdomain}] tip={check_type}")
            rows = self.run_query(sql)
            result_value = float(list(rows[0].values())[0]) if rows else 0.0

            # 3. Anomali tipi ise Z-skoru hesapla
            violation = False
            if check_type == "anomaly":
                baseline_mean, baseline_std, z_score_val, violation = \
                    self._check_anomaly(rule_id, domain, subdomain, result_value, anomaly_thr)
            else:
                violation = result_value > 0

            # 4. İhlal varsa aksiyon al
            result_status = "Passed"
            if violation:
                result_status = "Failed"
                msg = (
                    f"[{domain}/{subdomain}] İhlal! Değer={result_value:.2f} | "
                    f"Tip={check_type} | Açıklama: {description}"
                )

                if z_score_val is not None:
                    msg += (
                        f" | Z={z_score_val:.2f} "
                        f"(Ort={baseline_mean:.2f}, Std={baseline_std:.2f})"
                    )

                if test_flag:
                    # Test modunda aksiyon yok, sadece log
                    self.log.warning(f"🧪 TEST MOD: {msg}")
                elif action == "fail":
                    self.fail_checks.append(msg)
                elif action == "warn":
                    self.warn_checks.append(msg)
            else:
                self.log.info(f"  ✅ PASS [{domain}/{subdomain}] değer={result_value:.2f}")

        except Exception as e:
            result_status = "Error"
            result_value  = -1.0
            error_msg = f"[{domain}/{subdomain}] Kural çalıştırılamadı: {e}"
            self.log.error(error_msg)
            self.warn_checks.append(error_msg)

        # 5. Sonucu vce_dq_executions tablosuna kaydet
        self.log_execution(
            dag=dag,
            rule_id=rule_id,
            rule_domain=domain,
            rule_subdomain=subdomain,
            dataset_name=rule.get("dataset_name"),
            table_name=rule.get("table_name"),
            check_type=check_type,
            sql_statement=sql,
            action=action,
            result_value=result_value,
            result_status=result_status,
            baseline_mean=baseline_mean,
            baseline_std=baseline_std,
            z_score=z_score_val,
        )

    def _check_anomaly(
        self,
        rule_id: int,
        domain: str,
        subdomain: str,
        current_value: float,
        threshold: float,
    ) -> tuple[float | None, float | None, float | None, bool]:
        """
        Anomali tespiti: geçmiş 30 gündeki değerlere göre Z-skoru hesaplar.

        1. vce_dq_executions'dan son 30 günün değerlerini çeker
        2. Ortalama ve standart sapma hesaplar
        3. Z-skoru = (current - mean) / std
        4. |Z| > threshold ise anomali

        Returns:
            (mean, std, z_score, is_anomaly) tuple'ı
        """
        # Son 30 günün geçmiş değerlerini çek (sadece Passed sonuçlar)
        historical = self.run_query(
            """SELECT result_value
               FROM vce_dq_executions
               WHERE rule_id = %s
                 AND result_status = 'Passed'
                 AND run_date >= NOW() - INTERVAL 30 DAY
               ORDER BY run_date DESC
               LIMIT 100""",
            (rule_id,)
        )

        values = [float(r["result_value"]) for r in historical if r["result_value"] is not None]

        # Yetersiz veri varsa baseline güncelle, anomali sayma
        if len(values) < 7:
            self.log.info(
                f"  ℹ️ Anomali [{domain}/{subdomain}]: "
                f"yetersiz geçmiş ({len(values)} < 7). Baseline biriktirilecek."
            )
            self._update_baseline(rule_id, domain, subdomain, values + [current_value])
            return None, None, None, False

        mean = statistics.mean(values)
        std  = statistics.stdev(values) if len(values) > 1 else 0.0

        # Standart sapma 0 ise her değer ortalamaya eşit — anomali yok
        if std == 0:
            return mean, std, 0.0, False

        z = abs(current_value - mean) / std
        is_anomaly = z > threshold

        self.log.info(
            f"  📊 Anomali [{domain}/{subdomain}]: "
            f"değer={current_value:.2f}, ort={mean:.2f}, std={std:.2f}, z={z:.2f} "
            f"(eşik={threshold}) → {'ANOMALI!' if is_anomaly else 'normal'}"
        )

        # Baseline'ı güncelle
        self._update_baseline(rule_id, domain, subdomain, values + [current_value])
        return mean, std, z, is_anomaly

    def _update_baseline(self, rule_id: int, domain: str, subdomain: str, values: list[float]) -> None:
        """Anomali taban değerlerini (istatistik) vce_anomaly_baselines tablosuna yazar."""
        if not values:
            return

        mean = statistics.mean(values)
        std  = statistics.stdev(values) if len(values) > 1 else 0.0
        sorted_v = sorted(values)
        p25 = sorted_v[len(sorted_v) // 4]
        p75 = sorted_v[3 * len(sorted_v) // 4]

        self.execute_dml(
            """INSERT INTO vce_anomaly_baselines
                   (rule_id, rule_domain, rule_subdomain, window_days, sample_count,
                    mean_value, std_value, min_value, max_value, p25_value, p75_value)
               VALUES (%s, %s, %s, 30, %s, %s, %s, %s, %s, %s, %s)
               ON DUPLICATE KEY UPDATE
                   sample_count = VALUES(sample_count),
                   mean_value   = VALUES(mean_value),
                   std_value    = VALUES(std_value),
                   min_value    = VALUES(min_value),
                   max_value    = VALUES(max_value),
                   p25_value    = VALUES(p25_value),
                   p75_value    = VALUES(p75_value),
                   last_updated = NOW()""",
            (rule_id, domain, subdomain, len(values),
             mean, std, min(values), max(values), p25, p75)
        )


# ── TableValidationOperator ───────────────────────────────────────────────────

class TableValidationOperator(VCEBaseOperator):
    """
    Kaynak ve hedef tablo sorgularını karşılaştıran operatör.

    vce_table_validations tablosundan tanımları yükler.
    Her tanım için:
      1. source_sql çalıştırılır
      2. target_sql çalıştırılır
      3. Sonuçlar comparison_type'a göre karşılaştırılır
      4. Fark varsa action'a göre fail/warn

    comparison_type:
      exact    : Sıralanmış sonuçlar birebir eşleşmeli
      count    : Satır sayıları eşit olmalı
      sum      : Sayısal toplamlar eşit olmalı
      tolerance: Yüzde fark, tolerance_pct içinde olmalı (ör: %1.5)

    MailSender kullanım örnekleri:
      - send_queue.sent_count vs send_queue_log satır sayısı
      - suppression_list vs send_log'da suppressed adreslere gönderim
      - Her sender'ın log satır sayısı vs DB kanalındaki kayıt
    """

    template_fields = ("validation_domain", "validation_subdomain")

    @apply_defaults
    def __init__(
        self,
        validation_domain: str,
        validation_subdomain: str | None = None,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.validation_domain    = validation_domain
        self.validation_subdomain = validation_subdomain

    def execute(self, context: dict) -> None:
        dag = {
            "dag_id"   : context["dag"].dag_id,
            "dag_run"  : context["dag_run"].run_id,
            "task_name": context["task"].task_id,
            "retry"    : context["ti"].try_number,
        }

        validations = self._load_validations()
        self.log.info(f"📋 {len(validations)} tablo karşılaştırması yüklendi.")

        for val in validations:
            self._execute_validation(val, dag)

        if self.warn_checks:
            self.send_notifications(f"Table Validation WARN — {self.validation_domain}", self.warn_checks)

        if self.fail_checks:
            self.send_notifications(f"Table Validation FAIL — {self.validation_domain}", self.fail_checks)
            raise AirflowException(
                f"❌ {len(self.fail_checks)} tablo karşılaştırması başarısız:\n"
                + "\n".join(self.fail_checks)
            )

        self.log.info("✅ Tüm tablo karşılaştırmaları tamamlandı.")

    def _load_validations(self) -> list[dict]:
        conditions = ["active_flag = 1", "validation_domain = %s"]
        params: list = [self.validation_domain]

        if self.validation_subdomain:
            conditions.append("validation_subdomain = %s")
            params.append(self.validation_subdomain)

        sql = f"""
            SELECT id, validation_domain, validation_subdomain,
                   source_conn_id, source_dataset, source_table, source_sql, pre_source_sql,
                   target_conn_id, target_dataset, target_table, target_sql, pre_target_sql,
                   comparison_type, tolerance_pct, action, description, test_flag
            FROM vce_table_validations
            WHERE {' AND '.join(conditions)}
        """
        return self.run_query(sql, tuple(params))

    def _execute_validation(self, val: dict, dag: dict) -> None:
        """Tek bir karşılaştırmayı çalıştırır."""
        domain    = val["validation_domain"]
        subdomain = val["validation_subdomain"]
        action    = val["action"]

        result_status = "Passed"
        diff_detail   = None

        try:
            # Hazırlık sorguları
            if val.get("pre_source_sql"):
                self.run_query(val["pre_source_sql"])
            if val.get("pre_target_sql"):
                self.run_query(val["pre_target_sql"])

            # Kaynak ve hedef sorguları
            source_rows = self.run_query(val["source_sql"])
            target_rows = self.run_query(val["target_sql"])

            # Karşılaştır
            is_valid, diff_detail = self._compare(
                source_rows, target_rows,
                val["comparison_type"],
                val.get("tolerance_pct") or 0.0
            )

            if not is_valid:
                result_status = "Failed"
                msg = (
                    f"[{domain}/{subdomain}] Karşılaştırma başarısız! "
                    f"Tip={val['comparison_type']} | {diff_detail}"
                )
                if val["test_flag"]:
                    self.log.warning(f"🧪 TEST: {msg}")
                elif action == "fail":
                    self.fail_checks.append(msg)
                else:
                    self.warn_checks.append(msg)
            else:
                self.log.info(f"  ✅ PASS [{domain}/{subdomain}]")

        except Exception as e:
            result_status = "Error"
            diff_detail   = str(e)
            self.log.error(f"[{domain}/{subdomain}] Hata: {e}")
            self.warn_checks.append(f"[{domain}/{subdomain}] Çalıştırma hatası: {e}")

        # Kayıt
        self._log_val_execution(val, dag, source_rows if "source_rows" in dir() else [],
                                target_rows if "target_rows" in dir() else [],
                                result_status, diff_detail)

    def _compare(
        self,
        source: list[dict],
        target: list[dict],
        comparison_type: str,
        tolerance_pct: float,
    ) -> tuple[bool, str | None]:
        """
        Kaynak ve hedef sonuçlarını comparison_type'a göre karşılaştırır.

        Returns:
            (is_valid, diff_detail) tuple'ı.
            is_valid=True ise karşılaştırma başarılı.
        """
        if not source and not target:
            return True, None

        if not source:
            return False, "Kaynak sorgu boş sonuç döndürdü."

        if not target:
            return False, "Hedef sorgu boş sonuç döndürdü."

        if comparison_type == "count":
            if len(source) != len(target):
                return False, f"Satır sayısı farklı: kaynak={len(source)}, hedef={len(target)}"
            return True, None

        if comparison_type == "sum":
            s_val = sum(float(list(r.values())[0]) for r in source if list(r.values())[0])
            t_val = sum(float(list(r.values())[0]) for r in target if list(r.values())[0])
            if abs(s_val - t_val) > 0.01:
                return False, f"Toplam farklı: kaynak={s_val:.2f}, hedef={t_val:.2f}"
            return True, None

        if comparison_type == "tolerance":
            s_val = float(list(source[0].values())[0]) if source else 0.0
            t_val = float(list(target[0].values())[0]) if target else 0.0
            if t_val == 0:
                return s_val == 0, "Hedef değer 0, kaynak sıfır değil." if s_val != 0 else None
            pct_diff = abs(s_val - t_val) / t_val * 100
            if pct_diff > tolerance_pct:
                return False, (f"Yüzde fark %{pct_diff:.2f} > eşik %{tolerance_pct:.2f} "
                               f"(kaynak={s_val}, hedef={t_val})")
            return True, None

        # Varsayılan: exact karşılaştırma
        # Sıralama yaparak karşılaştır
        def normalize(rows):
            return sorted([tuple(str(v) for v in r.values()) for r in rows])

        s_norm = normalize(source)
        t_norm = normalize(target)

        if s_norm != t_norm:
            # İlk farklı satırı bul
            for i, (s, t) in enumerate(zip(s_norm, t_norm)):
                if s != t:
                    return False, f"Satır {i+1} farklı: kaynak={s}, hedef={t}"
            if len(s_norm) != len(t_norm):
                return False, f"Satır sayısı farklı: kaynak={len(s_norm)}, hedef={len(t_norm)}"

        return True, None

    def _log_val_execution(self, val, dag, source_rows, target_rows, status, diff):
        """Karşılaştırma sonucunu vce_table_val_executions tablosuna kaydeder."""
        # Sonuçları metin olarak serialize et (max 5000 karakter)
        def serialize(rows):
            txt = str(rows)
            return txt[:5000] if len(txt) > 5000 else txt

        try:
            self.execute_dml(
                """INSERT INTO vce_table_val_executions (
                       validation_id, validation_domain, validation_subdomain,
                       dag_id, dag_task_name, dag_run, task_retry_count,
                       source_conn_id, source_dataset, source_table, source_sql, source_result,
                       target_conn_id, target_dataset, target_table, target_sql, target_result,
                       result_status, diff_detail, run_date
                   ) VALUES (
                       %s, %s, %s, %s, %s, %s, %s,
                       %s, %s, %s, %s, %s,
                       %s, %s, %s, %s, %s,
                       %s, %s, NOW()
                   )""",
                (
                    val["id"], val["validation_domain"], val["validation_subdomain"],
                    dag["dag_id"], dag["task_name"], dag["dag_run"], dag["retry"],
                    val["source_conn_id"], val.get("source_dataset"),
                    val.get("source_table"), val["source_sql"][:2000], serialize(source_rows),
                    val["target_conn_id"], val.get("target_dataset"),
                    val.get("target_table"), val["target_sql"][:2000], serialize(target_rows),
                    status, diff,
                )
            )
        except Exception as e:
            self.log.warning(f"TableValidation kaydı yazılamadı: {e}")


# ── RemediationOperator ───────────────────────────────────────────────────────

class RemediationOperator(VCEBaseOperator):
    """
    Otomatik temizlik ve düzeltme operatörü.

    Güvenli DELETE/UPDATE işlemleri yapar ve her işlemi vce_remediation_log
    tablosuna kaydeder. Böylece "Bu gece ne silindi?" sorusu yanıtlanabilir.

    KURAL: Bu operatör sadece açıkça tanımlanmış temizlik işlemleri yapar.
    Hiçbir zaman iş verisi (send_log, suppression_list aktif kayıtlar) silmez.

    Desteklenen işlemler (operation_type):
      - delete_expired_tokens   : Süresi dolmuş şifre sıfırlama tokenları
      - delete_expired_unsub    : Süresi dolmuş kullanılmamış unsubscribe tokenları
      - delete_old_rate_logs    : Eski rate limit logları (>7 gün)
      - delete_old_ses_notif    : Eski SES bildirimleri (>90 gün)
      - flag_stuck_queue        : Takılı queue görevlerini logla (silme!)
      - report_suppression_violation: Suppression ihlallerini tespit ve logla
    """

    OPERATIONS = {
        "delete_expired_tokens": {
            "sql": """DELETE FROM password_reset_tokens
                      WHERE (used = 1 OR expires_at < NOW())
                        AND created_at < NOW() - INTERVAL 7 DAY""",
            "table": "password_reset_tokens",
            "description": "Süresi dolmuş/kullanılmış şifre sıfırlama tokenları temizlendi.",
        },
        "delete_expired_unsub": {
            "sql": """DELETE FROM unsubscribe_tokens
                      WHERE used = 0 AND expires_at < NOW() - INTERVAL 30 DAY""",
            "table": "unsubscribe_tokens",
            "description": "30+ gün önce süresi dolmuş kullanılmamış unsubscribe tokenları temizlendi.",
        },
        "delete_old_rate_logs": {
            "sql": "DELETE FROM rate_limit_log WHERE hit_at < NOW() - INTERVAL 7 DAY",
            "table": "rate_limit_log",
            "description": "7+ günlük eski rate limit logları temizlendi.",
        },
        "delete_old_ses_notif": {
            "sql": "DELETE FROM ses_notifications WHERE received_at < NOW() - INTERVAL 90 DAY",
            "table": "ses_notifications",
            "description": "90+ günlük eski SES bildirimleri temizlendi.",
        },
    }

    @apply_defaults
    def __init__(self, operations: list[str], *args, **kwargs):
        """
        Args:
            operations: Çalıştırılacak işlem listesi.
                        Ör: ['delete_expired_tokens', 'delete_old_rate_logs']
                        'all' verirsen tüm tanımlı işlemler çalışır.
        """
        super().__init__(*args, **kwargs)
        self.operations = list(self.OPERATIONS.keys()) if operations == ["all"] else operations

    def execute(self, context: dict) -> None:
        dag = {
            "dag_id"   : context["dag"].dag_id,
            "dag_run"  : context["dag_run"].run_id,
            "task_name": context["task"].task_id,
        }

        results = []

        for op_type in self.operations:
            if op_type not in self.OPERATIONS:
                self.log.warning(f"Bilinmeyen işlem tipi atlandı: {op_type}")
                continue

            result = self._run_operation(op_type, dag)
            results.append(result)

        # Özet log
        total_deleted = sum(r.get("rows_affected", 0) for r in results)
        self.log.info(f"🧹 Remediation tamamlandı. Toplam etkilenen: {total_deleted} satır.")

        # Suppression ihlali varsa fail
        violations = [r for r in results if r.get("operation_type") == "report_suppression_violation"
                      and r.get("rows_affected", 0) > 0]
        if violations:
            raise AirflowException(
                f"❌ Suppression ihlali tespit edildi! "
                f"Manuel inceleme gerekli. Detay: vce_remediation_log tablosuna bakın."
            )

    def _run_operation(self, op_type: str, dag: dict) -> dict:
        """Tek bir temizlik işlemini çalıştırır ve loglar."""
        op = self.OPERATIONS[op_type]
        rows_affected = 0
        status = "Success"
        detail = op["description"]

        try:
            rows_affected = self.execute_dml(op["sql"])
            self.log.info(f"  ✅ {op_type}: {rows_affected} satır etkilendi.")

        except Exception as e:
            status = "Failed"
            detail = str(e)
            self.log.error(f"  ❌ {op_type} başarısız: {e}")

        # Remediation loguna kaydet
        try:
            self.execute_dml(
                """INSERT INTO vce_remediation_log
                       (dag_id, dag_run, task_name, operation_type, target_table,
                        sql_executed, rows_affected, result_status, result_detail)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (dag["dag_id"], dag["dag_run"], dag["task_name"],
                 op_type, op["table"], op["sql"][:2000],
                 rows_affected, status, detail)
            )
        except Exception as e:
            self.log.warning(f"Remediation log yazılamadı: {e}")

        return {"operation_type": op_type, "rows_affected": rows_affected, "status": status}
